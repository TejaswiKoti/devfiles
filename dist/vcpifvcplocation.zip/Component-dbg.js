sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("vcpif.vcplocation.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);